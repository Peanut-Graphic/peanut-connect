<?php
/**
 * Visual feedback module — relays the same-origin WP REST endpoints used by
 * the feedback widget (built in a later task) to Hub's
 * /api/v1/connect/feedback* API, signed with the site's existing Hub key.
 *
 * Pin endpoints accept callers per the site's access mode (option
 * peanut_connect_feedback_access): the mode's automatic grant or a valid
 * review token; 'off' rejects everyone. The replies endpoints additionally
 * require an agency user (edit_posts) — Hub's reply index can include
 * is_internal replies, and review-token clients must never reach those.
 *
 * @package Peanut_Connect
 */

if (! defined('ABSPATH')) {
    exit;
}

class Peanut_Connect_Feedback {

    /** Cookie that carries a matched review token across the site for a reviewer. */
    const REVIEW_COOKIE = 'pp_review';

    /** Option: who gets Mark It Up automatically. 'editors'|'users'|'token'|'off'. */
    const ACCESS_OPTION = 'peanut_connect_feedback_access';

    /** Option: WP user IDs granted access when ACCESS_OPTION is 'users'. */
    const ALLOWED_USERS_OPTION = 'peanut_connect_feedback_allowed_users';

    /**
     * Whitelist + coerce the store payload; the agency flag is decided by
     * the SERVER based on the authenticated caller, never trusted from the
     * client-supplied request body.
     */
    public static function build_store_payload(array $req, bool $is_agency): array {
        return [
            // Only same-site paths — blocks javascript:, https?: and protocol-relative (//) values.
            'page_url'         => (isset($req['page_url']) && is_string($req['page_url']) && preg_match('#^/(?!/)#', $req['page_url']) === 1) ? $req['page_url'] : '/',
            'page_title'       => isset($req['page_title']) ? (string) $req['page_title'] : null,
            'anchor_selector'  => isset($req['anchor_selector']) ? (string) $req['anchor_selector'] : null,
            'anchor_x'         => (float) ($req['anchor_x'] ?? 0),
            'anchor_y'         => (float) ($req['anchor_y'] ?? 0),
            'viewport_width'   => isset($req['viewport_width']) ? (int) $req['viewport_width'] : null,
            'author_name'      => (string) ($req['author_name'] ?? ''),
            'author_is_agency' => $is_agency, // forced server-side; never trust the request body.
            'author_key'       => isset($req['author_key']) ? (string) $req['author_key'] : null,
            'body'             => (string) ($req['body'] ?? ''),
        ];
    }

    /**
     * Normalize a raw option value to a known access mode. Anything
     * unrecognized — including a missing option (false) on sites that
     * updated from <=3.20.0 — means 'editors', today's behavior, so a
     * fleet update changes nothing until someone touches the setting.
     */
    public static function normalize_access_mode($raw): string {
        return in_array($raw, ['users', 'token', 'off'], true) ? $raw : 'editors';
    }

    /**
     * Coerce a posted/stored allowed-user list to unique positive ints.
     */
    public static function sanitize_allowed_user_ids($raw): array {
        $ids = array_map('intval', is_array($raw) ? $raw : []);
        $ids = array_filter($ids, static function ($id) {
            return $id > 0;
        });
        return array_values(array_unique($ids));
    }

    /**
     * The AUTOMATIC access grant for the current visitor — pure so it can
     * be unit-tested without WP state. The token/cookie path is separate
     * and additive (handled by the callers); this decides only what a
     * login gets you by itself. 'off' short-circuits in the callers too,
     * where it must also defeat the token path.
     */
    public static function compute_user_grant(string $mode, bool $is_agency, bool $logged_in, int $user_id, array $allowed_ids): bool {
        switch ($mode) {
            case 'off':
            case 'token':
                return false;
            case 'users':
                return $logged_in && in_array($user_id, array_map('intval', $allowed_ids), true);
            default: // 'editors'
                return $is_agency;
        }
    }

    private static function access_mode(): string {
        return self::normalize_access_mode(get_option(self::ACCESS_OPTION, 'editors'));
    }

    private static function user_grant(string $mode): bool {
        return self::compute_user_grant(
            $mode,
            self::is_agency(),
            is_user_logged_in(),
            (int) get_current_user_id(),
            (array) get_option(self::ALLOWED_USERS_OPTION, [])
        );
    }

    public static function init(): void {
        add_action('rest_api_init', [self::class, 'register_routes']);
        add_action('admin_menu', [self::class, 'admin_menu']);
        add_action('init', [self::class, 'maybe_persist_review_cookie']);
        self::boot_frontend();
    }

    /**
     * Add a "Feedback Review" subpage under the End-to-End menu where an
     * agency admin can set/generate the per-site review token and copy the
     * client review link (the ?pp_review=… surface). Only registered when
     * the feedback module boots (i.e. the site is Hub-connected).
     */
    public static function admin_menu(): void {
        add_submenu_page(
            'peanut-connect-app',
            __('Mark It Up', 'peanut-connect'),
            __('Mark It Up', 'peanut-connect'),
            'manage_options',
            'peanut-connect-feedback-review',
            [self::class, 'render_admin_page']
        );
    }

    /**
     * Render + handle the review-token settings page. Admin-only, nonce-gated.
     */
    public static function render_admin_page(): void {
        if (! current_user_can('manage_options')) {
            return;
        }

        if (isset($_GET['pca_view']) && $_GET['pca_view'] === 'record' && class_exists('Peanut_Connect_Approvals')) {
            Peanut_Connect_Approvals::render_record_view();
            return;
        }

        $notice = '';
        $action = isset($_POST['pcf_action'])
            ? sanitize_key(wp_unslash($_POST['pcf_action']))
            : '';
        if ($action !== '' && check_admin_referer('pcf_review_token')) {
            if ($action === 'generate') {
                $token = bin2hex(random_bytes(20)); // 40-char hex secret
            } else {
                $token = sanitize_text_field(wp_unslash($_POST['pcf_review_token'] ?? ''));
            }
            update_option('peanut_connect_feedback_review_token', $token);

            // Access mode + allowed users save on the same nonce/submit.
            $mode_in = sanitize_key(wp_unslash($_POST['pcf_access_mode'] ?? 'editors'));
            update_option(self::ACCESS_OPTION, self::normalize_access_mode($mode_in));
            update_option(
                self::ALLOWED_USERS_OPTION,
                self::sanitize_allowed_user_ids(wp_unslash($_POST['pcf_allowed_users'] ?? []))
            );

            // Push the new token to Hub immediately (rather than waiting for
            // the next 15-minute cron heartbeat) so View-on-page links are
            // usable right away. Reuses the existing heartbeat sync — no new
            // sync infrastructure. Best-effort: a failure here doesn't block
            // saving locally, the periodic heartbeat will retry.
            if (class_exists('Peanut_Connect_Hub_Sync')) {
                Peanut_Connect_Hub_Sync::send_heartbeat();
            }

            $notice = $token === ''
                ? __('Settings saved. Review token is blank — client review links are disabled.', 'peanut-connect')
                : __('Settings saved.', 'peanut-connect');
        }

        $token   = (string) get_option('peanut_connect_feedback_review_token', '');
        $example = $token !== '' ? esc_url(add_query_arg('pp_review', $token, home_url('/'))) : '';

        $mode        = self::access_mode();
        $allowed_ids = self::sanitize_allowed_user_ids(get_option(self::ALLOWED_USERS_OPTION, []));
        // Everyone who could review as a logged-in user. 'capability' needs
        // WP 5.9+ (fleet floor is 6.0). Capped at 100 — these are agency and
        // client editor accounts, not open-registration user bases.
        $reviewers   = get_users([
            'capability' => 'edit_posts',
            'number'     => 100,
            'orderby'    => 'display_name',
            'order'      => 'ASC',
        ]);
        ?>
        <div class="wrap">
            <h1><?php esc_html_e('Mark It Up — Client Review Link', 'peanut-connect'); ?></h1>
            <?php if ($notice !== '') : ?>
                <div class="notice notice-success is-dismissible"><p><?php echo esc_html($notice); ?></p></div>
            <?php endif; ?>

            <p style="max-width:640px">
                <?php esc_html_e('Set a review token to let clients leave on-page feedback without a WordPress login. Logged-in editors already see the feedback widget and do NOT need this token. Share the link below with a reviewer — anyone with it can drop pinned notes on the site (their replies stay agency-only).', 'peanut-connect'); ?>
            </p>

            <form method="post">
                <?php wp_nonce_field('pcf_review_token'); ?>
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row"><?php esc_html_e('Who can mark up this site', 'peanut-connect'); ?></th>
                        <td>
                            <fieldset>
                                <legend class="screen-reader-text"><?php esc_html_e('Who can mark up this site', 'peanut-connect'); ?></legend>
                                <label><input type="radio" name="pcf_access_mode" value="editors" <?php checked($mode, 'editors'); ?> />
                                    <?php esc_html_e('Everyone with edit access + review link', 'peanut-connect'); ?></label>
                                <p class="description"><?php esc_html_e('Logged-in users who can edit posts see the widget automatically. Default.', 'peanut-connect'); ?></p>

                                <label><input type="radio" name="pcf_access_mode" value="users" <?php checked($mode, 'users'); ?> />
                                    <?php esc_html_e('Specific users + review link', 'peanut-connect'); ?></label>
                                <p class="description"><?php esc_html_e('Only the users checked below see the widget automatically.', 'peanut-connect'); ?></p>

                                <div id="pcf-user-checklist" style="margin:4px 0 12px 24px; max-height:220px; overflow-y:auto; <?php echo $mode === 'users' ? '' : 'display:none;'; ?>">
                                    <?php if (empty($reviewers)) : ?>
                                        <p class="description"><?php esc_html_e('No users with edit access found.', 'peanut-connect'); ?></p>
                                    <?php else : ?>
                                        <?php foreach ($reviewers as $reviewer) : ?>
                                            <label style="display:block; margin:2px 0;">
                                                <input type="checkbox" name="pcf_allowed_users[]" value="<?php echo esc_attr((string) $reviewer->ID); ?>" <?php checked(in_array((int) $reviewer->ID, $allowed_ids, true)); ?> />
                                                <?php echo esc_html($reviewer->display_name); ?>
                                                <span class="description">(<?php echo esc_html($reviewer->user_login); ?>)</span>
                                            </label>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </div>

                                <label><input type="radio" name="pcf_access_mode" value="token" <?php checked($mode, 'token'); ?> />
                                    <?php esc_html_e('Review link only', 'peanut-connect'); ?></label>
                                <p class="description"><?php esc_html_e('Nobody sees the widget automatically — only visitors who open the review link below.', 'peanut-connect'); ?></p>

                                <label><input type="radio" name="pcf_access_mode" value="off" <?php checked($mode, 'off'); ?> />
                                    <?php esc_html_e('Off', 'peanut-connect'); ?></label>
                                <p class="description"><?php esc_html_e('Mark It Up is disabled on this site. The review link stops working too.', 'peanut-connect'); ?></p>
                            </fieldset>
                            <script>
                            (function () {
                                var list = document.getElementById('pcf-user-checklist');
                                var radios = document.querySelectorAll('input[name="pcf_access_mode"]');
                                function sync() {
                                    var checked = document.querySelector('input[name="pcf_access_mode"]:checked');
                                    list.style.display = (checked && checked.value === 'users') ? '' : 'none';
                                }
                                for (var i = 0; i < radios.length; i++) {
                                    radios[i].addEventListener('change', sync);
                                }
                            })();
                            </script>
                        </td>
                    </tr>
                </table>

                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row"><label for="pcf_review_token"><?php esc_html_e('Review token', 'peanut-connect'); ?></label></th>
                        <td>
                            <input name="pcf_review_token" id="pcf_review_token" type="text" class="regular-text code" value="<?php echo esc_attr($token); ?>" autocomplete="off" />
                            <p class="description"><?php esc_html_e('A shared secret. Leave blank and save to disable client review links.', 'peanut-connect'); ?></p>
                        </td>
                    </tr>
                    <?php if ($example !== '') : ?>
                    <tr>
                        <th scope="row"><?php esc_html_e('Share link', 'peanut-connect'); ?></th>
                        <td>
                            <input type="text" class="large-text code" readonly onclick="this.select()" value="<?php echo esc_attr($example); ?>" />
                            <p class="description"><?php esc_html_e('Send a reviewer this link. Once they open it, review mode follows them across the whole site (for 30 days) — no need to re-add the token to every page. You can also append ?pp_review=… to any specific page URL.', 'peanut-connect'); ?></p>
                        </td>
                    </tr>
                    <?php endif; ?>
                </table>
                <p>
                    <button type="submit" name="pcf_action" value="save" class="button button-primary"><?php esc_html_e('Save settings', 'peanut-connect'); ?></button>
                    <button type="submit" name="pcf_action" value="generate" class="button"><?php esc_html_e('Generate a new token', 'peanut-connect'); ?></button>
                </p>
            </form>
            <?php
            if (class_exists('Peanut_Connect_Approvals')) {
                Peanut_Connect_Approvals::render_admin_section();
            }
            ?>
        </div>
        <?php
    }

    /**
     * Hook the frontend widget enqueue + footer container behind the
     * review-mode gate. Split out from init() so it can be unit-tested
     * (or re-bootstrapped) independently of the REST route registration.
     */
    public static function boot_frontend(): void {
        add_action('wp_enqueue_scripts', [self::class, 'enqueue']);
        add_action('wp_footer', [self::class, 'render_root']);
    }

    /**
     * Review mode is active for a logged-in agency user (can edit_posts),
     * or for any visitor carrying a ?pp_review=<token> query arg matching
     * the site's configured review token. hash_equals() is used to avoid
     * timing attacks, and an empty configured token never matches (an
     * empty request token is also rejected) so a freshly-installed site
     * with no token set never accidentally opens review mode to the public.
     */
    private static function review_active(): bool {
        $mode = self::access_mode();
        if ($mode === 'off') {
            return false; // off beats everything, including a valid token or cookie
        }
        if (self::user_grant($mode)) {
            return true;
        }

        $expected = (string) get_option('peanut_connect_feedback_review_token', '');
        if ($expected === '') {
            return false;
        }

        // Token can arrive on the URL (?pp_review=…) or, once a reviewer has
        // followed one tokenized link, from the cookie we set for them — so
        // they can browse the whole site without re-appending the token to
        // every internal link.
        $url_token    = isset($_GET['pp_review']) ? sanitize_text_field(wp_unslash($_GET['pp_review'])) : '';
        $cookie_token = isset($_COOKIE[self::REVIEW_COOKIE]) ? sanitize_text_field(wp_unslash($_COOKIE[self::REVIEW_COOKIE])) : '';

        return self::token_matches($expected, $url_token)
            || self::token_matches($expected, $cookie_token);
    }

    /**
     * Strict token comparison seam. The string "0" is a valid configured
     * value and must not be discarded by PHP's empty-value coercion.
     */
    public static function token_matches(string $expected, string $candidate): bool {
        return $expected !== '' && $candidate !== '' && hash_equals($expected, $candidate);
    }

    /**
     * When a reviewer arrives on a tokenized URL (?pp_review=<token>) that
     * matches the site's review token, drop a cookie so review mode follows
     * them across the whole site (plain internal links don't carry the query
     * arg). Runs on `init` — before headers are sent — so setcookie() works.
     * The cookie only ever holds the same token the reviewer already had in
     * the link, so it grants no access they didn't already have.
     */
    public static function maybe_persist_review_cookie(): void {
        if (self::access_mode() === 'off') {
            return;
        }
        if (! isset($_GET['pp_review']) || $_GET['pp_review'] === '') {
            return;
        }
        $expected = (string) get_option('peanut_connect_feedback_review_token', '');
        $token    = sanitize_text_field(wp_unslash($_GET['pp_review']));
        if (! self::token_matches($expected, $token)) {
            return;
        }
        if (isset($_COOKIE[self::REVIEW_COOKIE]) && hash_equals($token, (string) $_COOKIE[self::REVIEW_COOKIE])) {
            return; // already set to this token
        }
        setcookie(self::REVIEW_COOKIE, $token, [
            'expires'  => time() + 30 * DAY_IN_SECONDS,
            'path'     => defined('COOKIEPATH') && COOKIEPATH ? COOKIEPATH : '/',
            'domain'   => defined('COOKIE_DOMAIN') ? COOKIE_DOMAIN : '',
            'secure'   => is_ssl(),
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
        $_COOKIE[self::REVIEW_COOKIE] = $token; // honor it on this same request
    }

    /**
     * Enqueue the feedback widget script (review mode only). The widget
     * renders into a Shadow DOM, so the page-level stylesheet can't pierce
     * it — instead the CSS source is injected as a JS string the widget
     * attaches inside the shadow root.
     */
    public static function enqueue(): void {
        if (! self::review_active()) {
            return;
        }

        wp_enqueue_script(
            'peanut-connect-feedback',
            plugins_url('assets/js/feedback.js', dirname(__FILE__)),
            [],
            // Version the asset by the plugin version so each release busts the
            // browser cache — a hardcoded constant would serve stale widget JS
            // forever after an update (the inline CSS updates, the JS wouldn't).
            defined('PEANUT_CONNECT_VERSION') ? PEANUT_CONNECT_VERSION : '1.0.0',
            true
        );

        $css = (string) @file_get_contents(plugin_dir_path(dirname(__FILE__)) . 'assets/css/feedback.css');
        wp_add_inline_script(
            'peanut-connect-feedback',
            'window.__ppFeedbackCss = ' . wp_json_encode($css) . ';',
            'before'
        );

        // The widget needs the token for its REST calls (X-Peanut-Review-Token).
        // It can arrive on this request's URL, or — for every page the reviewer
        // visits after the first — from the pp_review cookie set by
        // maybe_set_review_cookie(). The cookie is HttpOnly (the widget JS can
        // never read document.cookie), so it MUST be re-emitted here server-side;
        // before 3.19.2 cookie-borne reviewers got an empty token and every
        // note POST after the first page failed with a 401.
        $token = isset($_GET['pp_review']) ? sanitize_text_field(wp_unslash($_GET['pp_review'])) : '';
        if ($token === '' && isset($_COOKIE[self::REVIEW_COOKIE])) {
            $cookie_token = sanitize_text_field(wp_unslash($_COOKIE[self::REVIEW_COOKIE]));
            $expected     = (string) get_option('peanut_connect_feedback_review_token', '');
            if ($expected !== '' && $cookie_token !== '' && hash_equals($expected, $cookie_token)) {
                $token = $cookie_token;
            }
        }
        wp_localize_script('peanut-connect-feedback', 'peanutConnectFeedback', [
            'restUrl'     => esc_url_raw(rest_url('peanut-connect/v1/feedback')),
            'nonce'       => wp_create_nonce('wp_rest'),
            'isAgency'    => self::is_agency(),
            'reviewToken' => $token,
            'approvers'   => class_exists('Peanut_Connect_Approvals') ? Peanut_Connect_Approvals::approvers() : [],
            'youApproverId' => class_exists('Peanut_Connect_Approvals') ? Peanut_Connect_Approvals::you_approver_id() : '',
        ]);
    }

    /**
     * Print the widget's mount point just before </body> (review mode only).
     */
    public static function render_root(): void {
        if (! self::review_active()) {
            return;
        }

        echo '<div id="peanut-connect-feedback-root"></div>';
    }

    public static function register_routes(): void {
        $ns = PEANUT_CONNECT_API_NAMESPACE;

        register_rest_route($ns, '/feedback', [
            ['methods' => 'GET',  'callback' => [self::class, 'list_feedback'], 'permission_callback' => [self::class, 'can_review']],
            ['methods' => 'POST', 'callback' => [self::class, 'create'],        'permission_callback' => [self::class, 'can_review']],
        ]);
        register_rest_route($ns, '/feedback/summary', [
            'methods'             => 'GET',
            'callback'            => [self::class, 'summary'],
            'permission_callback' => [self::class, 'can_review'],
        ]);
        register_rest_route($ns, '/feedback/(?P<id>\d+)', [
            ['methods' => 'PATCH',  'callback' => [self::class, 'update'],      'permission_callback' => [self::class, 'can_review']],
            ['methods' => 'DELETE', 'callback' => [self::class, 'delete_item'], 'permission_callback' => [self::class, 'can_review']],
        ]);
        register_rest_route($ns, '/feedback/(?P<id>\d+)/replies', [
            ['methods' => 'GET',  'callback' => [self::class, 'list_replies'], 'permission_callback' => [self::class, 'can_review_agency']],
            ['methods' => 'POST', 'callback' => [self::class, 'create_reply'], 'permission_callback' => [self::class, 'can_review_agency']],
        ]);
    }

    /**
     * Pin-level gate. 'off' rejects everyone. Otherwise: the mode's
     * automatic grant (see compute_user_grant()) OR a valid
     * X-Peanut-Review-Token header. In 'users' mode an allowed
     * non-editor authenticates via the normal wp_rest cookie nonce.
     */
    public static function can_review(\WP_REST_Request $request): bool {
        $mode = self::access_mode();
        if ($mode === 'off') {
            return false;
        }
        if (self::user_grant($mode)) {
            return true;
        }

        $token = (string) $request->get_header('X-Peanut-Review-Token');
        $expected = (string) get_option('peanut_connect_feedback_review_token', '');

        return $expected !== '' && $token !== '' && hash_equals($expected, $token);
    }

    /**
     * Replies-level gate: agency only, AND the caller must hold pin access
     * under the current mode — a non-listed editor in 'users' mode, or an
     * agency user without the token in 'token' mode, can't reach replies
     * either. Review-token-only clients still never qualify (not agency):
     * Hub's reply index can return is_internal replies.
     */
    public static function can_review_agency(\WP_REST_Request $request): bool {
        return self::is_agency() && self::can_review($request);
    }

    /**
     * Capability that qualifies a logged-in user as an "agency" reviewer — the
     * automatic pin-CRUD grant in the default 'editors' mode AND the gate on
     * reading is_internal replies (can_review_agency).
     *
     * SECURITY (v3.21.1): this was `edit_posts`, which every Author and
     * Contributor holds — so on any multi-author site the default mode silently
     * handed feedback CRUD and internal-reply reads to low-trust roles. The
     * default is now `edit_others_posts` (Editors + Admins), matching who the
     * "agency" is meant to be. A site that genuinely wants the broader
     * everyone-who-can-edit behaviour can opt back in via the
     * `peanut_connect_feedback_agency_cap` filter. The review-token path is
     * unaffected — it never runs through this capability.
     *
     * @since 3.21.1
     */
    private const AGENCY_CAPABILITY = 'edit_others_posts';

    private static function agency_capability(): string {
        $cap = apply_filters('peanut_connect_feedback_agency_cap', self::AGENCY_CAPABILITY);
        return (is_string($cap) && $cap !== '') ? $cap : self::AGENCY_CAPABILITY;
    }

    private static function is_agency(): bool {
        return is_user_logged_in() && current_user_can(self::agency_capability());
    }

    /**
     * Relay a request to Hub's connect-feedback API, signed with the site's
     * Hub key, and forward Hub's JSON body + status code back to the caller.
     */
    private static function relay(string $method, string $path, ?array $body = null) {
        $hub_url = (string) get_option('peanut_connect_hub_url', '');
        $api_key = Peanut_Connect_Auth::get_hub_api_key();

        if ($hub_url === '' || $api_key === '') {
            return new \WP_Error(
                'not_connected',
                __('This site is not connected to a Hub install yet.', 'peanut-connect'),
                ['status' => 503]
            );
        }

        $endpoint = rtrim($hub_url, '/') . '/api/v1/connect' . $path;
        $encoded  = $body === null ? '' : (string) wp_json_encode($body);

        $headers = [
            'Authorization' => 'Bearer ' . $api_key,
            'Accept'        => 'application/json',
        ];
        // Only send Content-Type when there is a body. A bodyless GET carrying
        // Content-Type: application/json is routed by Hub to the POST/store
        // handler (verified end-to-end locally), which 422s the list/replies
        // GETs and breaks pin loading. GETs must go out without it.
        if ($body !== null) {
            $headers['Content-Type'] = 'application/json';
        }

        $args = [
            'method'  => $method,
            'timeout' => 15,
            'headers' => array_merge(
                $headers,
                Peanut_Connect_Auth::outbound_signature_headers($method, $endpoint, $encoded)
            ),
        ];
        if ($body !== null) {
            $args['body'] = $encoded;
        }

        $response = wp_remote_request($endpoint, $args);

        if (is_wp_error($response)) {
            return $response;
        }

        $status = (int) wp_remote_retrieve_response_code($response);
        $raw    = (string) wp_remote_retrieve_body($response);
        $data   = json_decode($raw, true);

        if (! is_array($data)) {
            $data = ['raw' => $raw];
        }

        return new \WP_REST_Response($data, $status > 0 ? $status : 502);
    }

    public static function list_feedback(\WP_REST_Request $request) {
        $page = rawurlencode((string) $request->get_param('page_url'));
        return self::relay('GET', '/feedback?page_url=' . $page);
    }

    public static function create(\WP_REST_Request $request) {
        $payload = self::build_store_payload($request->get_json_params() ?: [], self::is_agency());
        return self::relay('POST', '/feedback', $payload);
    }

    /**
     * Server-side note create for sibling modules (the approvals "what needs
     * to change" reason). Best-effort: relay/Hub failures return null and
     * must not block the caller — the reason also lives on the approval
     * record itself.
     */
    public static function store_note(array $req): ?int {
        $payload = self::build_store_payload($req, self::is_agency());
        $res     = self::relay('POST', '/feedback', $payload);
        if ($res instanceof \WP_REST_Response) {
            $data = $res->get_data();
            if (is_array($data) && isset($data['feedback']['id'])) {
                return (int) $data['feedback']['id'];
            }
        }
        return null;
    }

    public static function update(\WP_REST_Request $request) {
        $id = (int) $request['id'];
        $in = $request->get_json_params() ?: [];
        // Forward status/body/author_key for every caller — ownership of body
        // edits is enforced by Hub (author_key match) — plus caller_is_agency,
        // decided server-side here; Hub trusts this flag, never the widget.
        $allowed = ['status', 'body', 'author_key'];
        $body = array_intersect_key($in, array_flip($allowed));
        $body['caller_is_agency'] = self::is_agency();
        if (self::is_agency()) {
            $u = wp_get_current_user();
            $body['resolver_name'] = $u && $u->display_name ? $u->display_name : 'Web Team';
        }
        return self::relay('PATCH', "/feedback/{$id}", $body);
    }

    public static function delete_item(\WP_REST_Request $request) {
        $id   = (int) $request['id'];
        $body = array_intersect_key($request->get_json_params() ?: [], array_flip(['author_key']));
        $body['caller_is_agency'] = self::is_agency();
        return self::relay('DELETE', '/feedback/' . $id, $body);
    }

    public static function summary(\WP_REST_Request $request) {
        return self::relay('GET', '/feedback/summary', null);
    }

    public static function list_replies(\WP_REST_Request $request) {
        $id = (int) $request['id'];
        return self::relay('GET', "/feedback/{$id}/replies");
    }

    public static function create_reply(\WP_REST_Request $request) {
        $id = (int) $request['id'];
        $in = $request->get_json_params() ?: [];
        $body = [
            'author_name' => (string) ($in['author_name'] ?? ''),
            'body'        => (string) ($in['body'] ?? ''),
            // Only an agency caller (the only caller who can reach this
            // endpoint in v1) may mark a reply internal.
            'is_internal' => self::is_agency() && ! empty($in['is_internal']),
        ];
        return self::relay('POST', "/feedback/{$id}/replies", $body);
    }
}
